<?php

/**
 * manufakturGitDownloads
 *
 * @author Ralf Hertsch <ralf.hertsch@phpmanufaktur.de>
 * @link http://phpmanufaktur.de
 * @copyright 2012
 * @license MIT License (MIT) http://www.opensource.org/licenses/MIT
 */

if (!defined('LEPTON_PATH')) define('LEPTON_PATH', WB_PATH);
if (!defined('LEPTON_URL')) define('LEPTON_URL', WB_URL);